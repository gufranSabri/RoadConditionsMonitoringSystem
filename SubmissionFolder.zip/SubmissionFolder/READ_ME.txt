Miss Amwaj instructed us to submit the following in the USB

Soft copy of report          : file named ProjectReport.docx
Presentation slides          : file named Presentation.pptx  
Photos of project            : In a folder called ProjectImages
Video demo                   : not applicable to our project because it is a software project. Images are sufficient
Soft copy/layout of poster   : file called layout.png
Program codes                : visit the GitHub repository at => https://github.com/gufranSabri/RoadConditionsMonitoringSystem